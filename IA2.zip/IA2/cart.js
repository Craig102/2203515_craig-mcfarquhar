// Cart functionality for cart.html
'use strict';

// DOM elements
const cartItemsContainer = document.querySelector('.cart-items');
const emptyCart = document.getElementById('emptyCart');
const subtotalEl = document.getElementById('subtotal');
const discountEl = document.getElementById('discount');
const taxEl = document.getElementById('tax');
const totalEl = document.getElementById('total');
const clearCartBtn = document.getElementById('clearCart');
const checkoutBtn = document.getElementById('checkoutBtn');
const cartCountEl = document.querySelector('.cart-count');

// Initialize cart from localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Save cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Display cart items
function displayCartItems() {
    // Clear existing items except header
    const items = cartItemsContainer.querySelectorAll('.cart-item');
    items.forEach(item => item.remove());

    if (cart.length === 0) {
        emptyCart.style.display = 'block';
        return;
    }

    emptyCart.style.display = 'none';

    cart.forEach((item, index) => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'cart-item';
        itemDiv.innerHTML = `
            <span>${item.name}</span>
            <span>$${item.price}</span>
            <input type="number" min="1" value="${item.quantity}" class="quantity-input" data-index="${index}">
            <span class="subtotal">$${(item.price * item.quantity).toFixed(2)}</span>
            <button class="btn remove-btn" data-index="${index}"><i class="fas fa-trash"></i></button>
        `;
        cartItemsContainer.appendChild(itemDiv);
    });

    // Add event listeners for quantity and remove
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', handleQuantityChange);
    });
    document.querySelectorAll('.remove-btn').forEach(btn => {
        btn.addEventListener('click', handleRemoveItem);
    });
}

// Update cart summary
function updateCartSummary() {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = subtotal * 0.1;
    const taxable = subtotal - discount;
    const tax = taxable * 0.15;
    const total = taxable + tax;

    subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    discountEl.textContent = `$${discount.toFixed(2)}`;
    taxEl.textContent = `$${tax.toFixed(2)}`;
    totalEl.textContent = `$${total.toFixed(2)}`;
}

// Update cart count in header
function updateCartCount() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountEl.textContent = count;
}

// Handle quantity change
function handleQuantityChange(e) {
    const index = parseInt(e.target.dataset.index);
    const newQty = parseInt(e.target.value);
    if (newQty > 0) {
        cart[index].quantity = newQty;
        saveCart();
        updateCartSummary();
        updateCartCount();
        // Update subtotal display
        const subtotalSpan = e.target.nextElementSibling;
        subtotalSpan.textContent = `$${(cart[index].price * newQty).toFixed(2)}`;
    }
}

// Handle remove item
function handleRemoveItem(e) {
    const index = parseInt(e.target.closest('.remove-btn').dataset.index);
    cart.splice(index, 1);
    saveCart();
    displayCartItems();
    updateCartSummary();
    updateCartCount();
}

// Handle clear cart
function handleClearCart() {
    cart = [];
    saveCart();
    displayCartItems();
    updateCartSummary();
    updateCartCount();
}

// Handle checkout
function handleCheckout() {
    window.location.href = 'checkout.html';
}

// Event listeners
clearCartBtn.addEventListener('click', handleClearCart);
checkoutBtn.addEventListener('click', handleCheckout);

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    displayCartItems();
    updateCartSummary();
    updateCartCount();
});
