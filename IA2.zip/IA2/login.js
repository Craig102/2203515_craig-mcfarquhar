// Login functionality for login.html

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            const remember = document.querySelector('input[name="remember"]').checked;

            // Validation
            if (!username || !password) {
                showAlert('Please fill in all required fields', 'error');
                return;
            }

            // Sanitize input
            const sanitizedUsername = username.toLowerCase().replace(/[^a-z0-9]/g, '');

            // Check demo accounts first
            const demoAccounts = {
                'admin': hashPassword('password123'),
                'user': hashPassword('password123')
            };

            let authenticated = false;
            let userData = null;

            if (demoAccounts[sanitizedUsername] && demoAccounts[sanitizedUsername] === hashPassword(password)) {
                authenticated = true;
                userData = {
                    username: sanitizedUsername,
                    role: sanitizedUsername === 'admin' ? 'admin' : 'user',
                    loggedInAt: new Date().toISOString()
                };
            } else {
                // Check stored user (from register.js)
                const storedUser = getFromStorage('currentUser');
                if (storedUser && storedUser.username === sanitizedUsername && storedUser.password === hashPassword(password)) {
                    authenticated = true;
                    userData = {
                        ...storedUser,
                        loggedInAt: new Date().toISOString()
                    };
                }
            }

            if (authenticated) {
                // Save user data with session timestamp
                const sessionData = {
                    ...userData,
                    sessionStart: Date.now(),
                    sessionExpiry: Date.now() + (30 * 60 * 1000) // 30 minutes from now
                };
                saveToStorage('currentUser', sessionData);

                // Handle remember me
                if (remember) {
                    saveToStorage('rememberUser', true);
                } else {
                    localStorage.removeItem('rememberUser');
                }

                showAlert('Login successful! Redirecting...', 'success');

                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 2000);
            } else {
                showAlert('Invalid username or password', 'error');
            }
        });
    }


});

// Utility functions
function showAlert(message, type) {
    // Remove existing message
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Create new message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;

    // Insert after form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.appendChild(messageDiv);
    }

    // Auto-remove after 5 seconds for errors
    if (type === 'error') {
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 5000);
    }
}

function saveToStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

function getFromStorage(key) {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
}

// Simple hash function for demo purposes (not secure for production)
function hashPassword(password) {
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
        const char = password.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    return hash.toString();
}
