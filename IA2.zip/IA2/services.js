(function() {
  document.addEventListener('DOMContentLoaded', function() {
    initializeServicesPage();
  });

  function initializeServicesPage() {
    setupAddToCartButtons();
    setupAddBundleButtons();
    updateCartCount();
  }

  function setupAddToCartButtons() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
      button.addEventListener('click', handleAddToCart);
    });
  }

  function setupAddBundleButtons() {
    const addBundleButtons = document.querySelectorAll('.add-bundle');
    addBundleButtons.forEach(button => {
      button.addEventListener('click', handleAddBundle);
    });
  }

  function handleAddToCart(event) {
    const button = event.target;
    const service = button.getAttribute('data-service');
    const price = parseFloat(button.getAttribute('data-price'));

    addToCart(service, price, 'service');
    showAlert(`${service} added to cart!`, 'success');
    updateCartCount();
  }

  function handleAddBundle(event) {
    const button = event.target;
    const bundle = button.getAttribute('data-bundle');
    const price = parseFloat(button.getAttribute('data-price'));

    addToCart(bundle, price, 'bundle');
    showAlert(`${bundle} added to cart!`, 'success');
    updateCartCount();
  }

  function addToCart(item, price, type) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ name: item, price, type, quantity: 1, id: Date.now() });
    localStorage.setItem('cart', JSON.stringify(cart));
  }

  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
      cartCountElement.textContent = cart.length;
    }
  }

  function showAlert(message, type) {
    // Simple alert; can be enhanced with custom modal
    alert(message);
  }
})();
