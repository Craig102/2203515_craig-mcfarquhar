// Checkout functionality
document.addEventListener('DOMContentLoaded', function() {
    loadCart();
    updateCartCount();
    setupEventListeners();
});

function loadCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const orderItemsContainer = document.querySelector('.order-items');
    orderItemsContainer.innerHTML = '';

    if (cart.length === 0) {
        orderItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        updateTotals(0, 0, 0, 0);
        return;
    }

    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'order-item';
        itemDiv.innerHTML = `
            <span>${item.name} (${item.type})</span>
            <span>$${item.price.toFixed(2)} x ${item.quantity}</span>
            <span>$${(item.price * item.quantity).toFixed(2)}</span>
        `;
        orderItemsContainer.appendChild(itemDiv);
    });

    calculateTotals(cart);
}

function calculateTotals(cart) {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = subtotal * 0.1;
    const taxable = subtotal - discount;
    const tax = taxable * 0.15;
    const total = taxable + tax;

    updateTotals(subtotal, discount, tax, total);
}

function updateTotals(subtotal, discount, tax, total) {
    document.getElementById('orderSubtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('orderDiscount').textContent = `$${discount.toFixed(2)}`;
    document.getElementById('orderTax').textContent = `$${tax.toFixed(2)}`;
    document.getElementById('orderTotal').textContent = `$${total.toFixed(2)}`;
    document.getElementById('paymentAmount').value = total.toFixed(2);
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountEl = document.querySelector('.cart-count');
    if (cartCountEl) {
        cartCountEl.textContent = count;
    }
}

function setupEventListeners() {
    const confirmOrderBtn = document.getElementById('confirmOrder');
    const cancelCheckoutBtn = document.getElementById('cancelCheckout');
    const clearFormBtn = document.getElementById('clearForm');

    confirmOrderBtn.addEventListener('click', handleConfirmOrder);
    cancelCheckoutBtn.addEventListener('click', () => window.location.href = 'cart.html');
    clearFormBtn.addEventListener('click', () => document.getElementById('checkoutForm').reset());
}

function handleConfirmOrder() {
    const form = document.getElementById('checkoutForm');
    if (!form.checkValidity()) {
        alert('Please fill in all required fields.');
        return;
    }

    // Get cart data
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Calculate totals
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discount = subtotal * 0.1;
    const taxable = subtotal - discount;
    const tax = taxable * 0.15;
    const total = taxable + tax;

    // Payment amount is auto-populated and should match the total

    // Get form data
    const firstName = document.getElementById('firstName').value;
    const lastName = document.getElementById('lastName').value;
    const customerName = `${firstName} ${lastName}`;
    const customerEmail = document.getElementById('email').value;
    const streetAddress = document.getElementById('address').value;
    const city = document.getElementById('city').value;
    const zipCode = document.getElementById('zipCode').value;
    const country = document.getElementById('country').value;
    const customerAddress = `${streetAddress}, ${city}, ${zipCode}, ${country}`;

    // Generate invoice number and date
    const invoiceNumber = 'INV-' + Date.now();
    const invoiceDate = new Date().toLocaleDateString();
    const paymentDate = new Date().toLocaleDateString();

    // Store order details in localStorage
    const orderDetails = {
        customerName,
        customerEmail,
        customerAddress,
        cart,
        subtotal,
        discount,
        tax,
        total,
        paymentDate
    };
    localStorage.setItem('orderDetails', JSON.stringify(orderDetails));
    localStorage.setItem('invoiceNumber', invoiceNumber);
    localStorage.setItem('invoiceDate', invoiceDate);

    // Clear cart after order
    localStorage.removeItem('cart');

    // Redirect to invoice
    window.location.href = 'invoice.html';
}
