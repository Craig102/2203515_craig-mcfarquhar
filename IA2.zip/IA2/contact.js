(function() {
  document.addEventListener('DOMContentLoaded', function() {
    initializeContactPage();
  });

  function initializeContactPage() {
    setupContactForm();
    setupContactInteractions();
    setupFormValidation();
  }

  function setupContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
      contactForm.addEventListener('submit', handleContactFormSubmission);
      const inputs = contactForm.querySelectorAll('input[type="text"], input[type="email"], textarea');
      inputs.forEach(input => {
        input.addEventListener('blur', debounce(validateContactField, 500));
        input.addEventListener('input', function() {
          if (this.style.borderColor === 'red') {
            validateContactField(this);
          }
        });
      });
    }
  }

  function setupContactInteractions() {
    const infoItems = document.querySelectorAll('.info-item');
    infoItems.forEach(item => {
      item.addEventListener('mouseenter', function() {
        this.style.transform = 'translateX(10px)';
        this.style.transition = 'transform 0.3s ease';
      });
      item.addEventListener('mouseleave', function() {
        this.style.transform = 'translateX(0)';
      });
    });

    const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
    emailLinks.forEach(link => {
      link.addEventListener('click', handleEmailClick);
    });

    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
    phoneLinks.forEach(link => {
      link.addEventListener('click', handlePhoneClick);
    });

    animateBusinessHours();
  }

  function handleContactFormSubmission(event) {
    event.preventDefault();
    const form = event.target;
    const inputs = form.querySelectorAll('input, textarea');
    let isValid = true;
    inputs.forEach(input => {
      if (!validateContactField(input)) {
        isValid = false;
      }
    });
    if (isValid) {
      showAlert('Message sent successfully!', 'success');
      form.reset();
    } else {
      showAlert('Please correct the errors in the form.', 'error');
    }
  }

  function handleEmailClick(event) {
    event.preventDefault();
    const email = this.getAttribute('href').replace('mailto:', '');
    showAlert(`Opening email client to send message to ${email}`, 'info');
    setTimeout(() => {
      window.location.href = `mailto:${email}`;
    }, 1000);
  }

  function handlePhoneClick(event) {
    event.preventDefault();
    const phone = this.getAttribute('href').replace('tel:', '');
    showAlert(`Initiating phone call to ${phone}`, 'info');
    setTimeout(() => {
      window.location.href = `tel:${phone}`;
    }, 1000);
  }

  function setupFormValidation() {
    const inputs = document.querySelectorAll('#contactForm input, #contactForm textarea');
    inputs.forEach(input => {
      input.addEventListener('blur', debounce(validateContactField, 500));
      input.addEventListener('input', function() {
        if (this.style.borderColor === 'red') {
          validateContactField(this);
        }
      });
    });
  }

  function validateContactField(field) {
    const value = field.value;
    const fieldName = field.name;

    clearError(field);

    switch (fieldName) {
      case 'contactName':
        if (!validateRequired(value)) {
          showError(field, 'Name is required');
          return false;
        } else if (value.length < 2) {
          showError(field, 'Name must be at least 2 characters long');
          return false;
        }
        break;

      case 'contactEmail':
        if (!validateEmail(value)) {
          showError(field, 'Please enter a valid email address');
          return false;
        }
        break;

      case 'contactSubject':
        if (!validateRequired(value)) {
          showError(field, 'Please select a subject');
          return false;
        }
        break;

      case 'contactMessage':
        if (!validateRequired(value)) {
          showError(field, 'Message is required');
          return false;
        } else if (value.length < 10) {
          showError(field, 'Message must be at least 10 characters long');
          return false;
        }
        break;
    }

    return true;
  }

  function validateRequired(value) {
    return value.trim().length > 0;
  }

  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function showError(field, message) {
    field.style.borderColor = 'red';
    let errorElement = field.nextElementSibling;
    if (!errorElement || !errorElement.classList.contains('error-message')) {
      errorElement = document.createElement('div');
      errorElement.classList.add('error-message');
      field.parentNode.insertBefore(errorElement, field.nextSibling);
    }
    errorElement.textContent = message;
    errorElement.style.color = 'red';
    errorElement.style.fontSize = '0.9em';
    errorElement.style.marginTop = '5px';
  }

  function clearError(field) {
    field.style.borderColor = '';
    const errorElement = field.nextElementSibling;
    if (errorElement && errorElement.classList.contains('error-message')) {
      errorElement.remove();
    }
  }

  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  function showAlert(message, type) {
    // Simple alert for now; can be enhanced with custom modal
    alert(message);
  }

  function animateBusinessHours() {
    const hoursList = document.querySelector('.hours-list');
    if (hoursList) {
      hoursList.style.opacity = '0';
      setTimeout(() => {
        hoursList.style.transition = 'opacity 1s ease';
        hoursList.style.opacity = '1';
      }, 500);
    }
  }
})();
