// Register functionality for register.html

document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('registerForm');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    const termsLink = document.querySelector('.terms-link');

    // Password strength checker
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;

            // Length check
            if (password.length >= 8) strength += 25;

            // Lowercase check
            if (/[a-z]/.test(password)) strength += 25;

            // Uppercase check
            if (/[A-Z]/.test(password)) strength += 25;

            // Number/Special char check
            if (/[0-9]/.test(password) || /[^A-Za-z0-9]/.test(password)) strength += 25;

            // Update strength indicator
            strengthFill.style.width = strength + '%';

            if (strength <= 25) {
                strengthFill.style.background = '#EF4444';
                strengthText.textContent = 'Weak';
            } else if (strength <= 50) {
                strengthFill.style.background = '#F59E0B';
                strengthText.textContent = 'Fair';
            } else if (strength <= 75) {
                strengthFill.style.background = '#3B82F6';
                strengthText.textContent = 'Good';
            } else {
                strengthFill.style.background = '#10B981';
                strengthText.textContent = 'Strong';
            }
        });
    }

    // Confirm password validation
    if (confirmPasswordInput && passwordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            if (this.value !== passwordInput.value) {
                this.style.borderColor = '#EF4444';
            } else {
                this.style.borderColor = '';
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const firstName = document.getElementById('firstName').value;
            const lastName = document.getElementById('lastName').value;
            const email = document.getElementById('email').value;
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const termsAccepted = document.getElementById('terms').checked;

            // Validation
            if (!firstName || !lastName || !email || !username || !password || !confirmPassword) {
                showAlert('Please fill in all required fields', 'error');
                return;
            }

            if (!validateEmail(email)) {
                showAlert('Please enter a valid email address', 'error');
                return;
            }

            if (password.length < 6) {
                showAlert('Password must be at least 6 characters long', 'error');
                return;
            }

            if (password !== confirmPassword) {
                showAlert('Passwords do not match', 'error');
                return;
            }

            if (!termsAccepted) {
                showAlert('Please accept the Terms & Conditions', 'error');
                return;
            }

            // Simulate registration
            const userData = {
                firstName: firstName,
                lastName: lastName,
                email: email,
                username: username.toLowerCase().replace(/[^a-z0-9]/g, ''),
                password: hashPassword(password),
                registeredAt: new Date().toISOString()
            };

            saveToStorage('currentUser', userData);
            showAlert('Registration successful! Redirecting to login...', 'success');

            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        });
    }

    if (termsLink) {
        termsLink.addEventListener('click', function(e) {
            e.preventDefault();
            showAlert('Terms & Conditions would be displayed here in a real application.', 'info');
        });
    }
});

// Utility functions
function showAlert(message, type) {
    // Remove existing message
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Create new message element
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;

    // Insert after form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.appendChild(messageDiv);
    }

    // Auto-remove after 5 seconds for errors
    if (type === 'error') {
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 5000);
    }
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function saveToStorage(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// Simple hash function for demo purposes (not secure for production)
function hashPassword(password) {
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
        const char = password.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    return hash.toString();
}

