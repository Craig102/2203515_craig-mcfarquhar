document.addEventListener('DOMContentLoaded', function() {
    const invoiceNumberElement = document.getElementById('invoiceNumber');
    const invoiceDateElement = document.getElementById('invoiceDate');

    const invoiceNumber = localStorage.getItem('invoiceNumber');
    const invoiceDate = localStorage.getItem('invoiceDate');

    if (invoiceNumber && invoiceDate) {
        invoiceNumberElement.textContent = invoiceNumber;
        invoiceDateElement.textContent = invoiceDate;
    }

    // Load order details from localStorage
    const orderDetails = JSON.parse(localStorage.getItem('orderDetails'));
    if (orderDetails) {
        // Populate customer information
        document.getElementById('customerName').textContent = orderDetails.customerName;
        document.getElementById('customerEmail').textContent = orderDetails.customerEmail;
        document.getElementById('customerAddress').textContent = orderDetails.customerAddress;

        // Populate payment information
        document.getElementById('paymentDate').textContent = orderDetails.paymentDate;
        document.getElementById('amountPaid').textContent = `$${orderDetails.total.toFixed(2)}`;

        // Populate invoice items
        const invoiceItemsContainer = document.querySelector('.invoice-items tbody');
        invoiceItemsContainer.innerHTML = '';

        orderDetails.cart.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.name} (${item.type})</td>
                <td>${item.quantity}</td>
                <td>$${item.price.toFixed(2)}</td>
                <td>$${(item.price * item.quantity).toFixed(2)}</td>
            `;
            invoiceItemsContainer.appendChild(row);
        });

        // Populate totals
        document.getElementById('invoiceSubtotal').textContent = `$${orderDetails.subtotal.toFixed(2)}`;
        document.getElementById('invoiceDiscount').textContent = `$${orderDetails.discount.toFixed(2)}`;
        document.getElementById('invoiceTax').textContent = `$${orderDetails.tax.toFixed(2)}`;
        document.getElementById('invoiceTotal').textContent = `$${orderDetails.total.toFixed(2)}`;
    } else {
        // Handle case where no order details are found
        document.getElementById('customerName').textContent = 'No data available';
        document.getElementById('customerEmail').textContent = 'No data available';
        document.getElementById('customerAddress').textContent = 'No data available';
        document.getElementById('paymentDate').textContent = 'No data available';
        document.getElementById('amountPaid').textContent = '$0.00';
        document.querySelector('.invoice-items tbody').innerHTML = '<tr><td colspan="4">No items found</td></tr>';
    }
});
